package com.example.ca1226

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.LinearLayout
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.filament.View

class RecyclerView : AppCompatActivity() {

    lateinit var recyclerView: RecyclerView
    lateinit var adapter: ArrayAdapter<Thread>
    lateinit var list: MutableList<Cricketer>

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_recycler_view)

        recyclerView = findViewById(R.id.recyclerView)
        recyclerView.hasfixedSize(true)

        val gm = LinearLayoutManager()
        gm.setonClickListener()


        val ad = myCustomAdapter(R.myLookFile)

        



        }

    private fun myCustomAdapter(myLookFile: Any): Any {

    }

    private fun LinearLayoutManager(): Any {

    }
}

private fun View.hasfixedSize(b: Boolean) {

}
