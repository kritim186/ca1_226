package com.example.ca1226

import android.view.View
import com.google.android.gms.ads.mediation.Adapter

class CricketerAdapter(private val cricketerList: List<Cricketer>) :
    RecyclerView.Adapter<CricketerAdapter.CricketerViewHolder>() {

    class CricketerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nameTextView: TextView = itemView.findViewById(R.id.tvCricketerName)
        val scoreTextView: TextView = itemView.findViewById(R.id.tvCricketerScore)
        val matchesTextView: TextView = itemView.findViewById(R.id.tvCricketerMatches)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CricketerViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_cricketer, parent, false)
        return CricketerViewHolder(itemView)
    }

    override fun onBindViewHolder(holder: CricketerViewHolder, position: Int) {
        val currentCricketer = cricketerList[position]
        holder.nameTextView.text = currentCricketer.name
        holder.scoreTextView.text = "Score: ${currentCricketer.score}"
        holder.matchesTextView.text = "Matches: ${currentCricketer.matches}"
    }

    override fun getItemCount() = cricketerList.size
}
