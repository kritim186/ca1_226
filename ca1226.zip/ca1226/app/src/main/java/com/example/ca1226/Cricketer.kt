package com.example.ca1226

import android.provider.Telephony.Mms.Rate
data class Cricketer(
    val name: String,
    val score: Int,
    val matches: Int
)
